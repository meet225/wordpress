<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'nF#!Kq;0v:i]h/}Z$PurF,~HB6NMim1NmROM=qv~;H paj1FtA*7oi|mNE&>:Dx;' );
define( 'SECURE_AUTH_KEY',  'wSu ./]<$TD~=uG`-sqK];g*)d)? -icTQkj&hk*jiM<6;acNzTubbsp%@K6=QyI' );
define( 'LOGGED_IN_KEY',    '0UZ4]cR-vMmG!MX<j60{#F]y;}|`zW&:mxx1 Yu+tA`m~8N!-Rt5yqV/^7%N:rc2' );
define( 'NONCE_KEY',        'jK7=R>3&}wyvJU=1(8Ya[?a6Qv>S I8`C]!]t6~AM=|btLl<bs}}^0z(%VdX)}+(' );
define( 'AUTH_SALT',        '2$Q:l3RT)xA5)O/R$zd}7KmI@`ek.+nG&ab.u>,tI>681T $>Bv9*C#)VU{+miUe' );
define( 'SECURE_AUTH_SALT', '6wuT2!JyvP)Bi[bGd|YnwU,L.YXZ]#-|s0 p34WqWMPm!$8e]N/L6Y#uJ7PK7]aM' );
define( 'LOGGED_IN_SALT',   'UMhE|.$3Mv27FK1=pi/ZC18cSINokW0tFze#qwo_4CD@#;`X=w7=?=dHeqb<*n`g' );
define( 'NONCE_SALT',       'pyn!qUP#,UP8=mW1[9X-v}Qe`pia{kLL=*9mSjpNGyV:;-.FH!ejcp;*d]%fV)8T' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
